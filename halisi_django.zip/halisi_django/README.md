The goal with this research project is to learn the essential parts of the backend of an ecommerce application. My application will implement the features using Django and Vue.
Author
Mmaureeny-github.com
